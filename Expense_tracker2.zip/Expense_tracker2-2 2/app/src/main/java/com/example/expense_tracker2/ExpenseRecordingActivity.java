package com.example.expense_tracker2;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.common.api.Status;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;

import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

public class ExpenseRecordingActivity extends AppCompatActivity {

    private EditText titleInput, amountInput;
    private TextView dateInput, timeInput, locationInput;
    private Button saveExpenseButton, selectDateButton, selectTimeButton, selectLocationButton;

    private static final int AUTOCOMPLETE_REQUEST_CODE = 1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense_recording);

        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), "AIzaSyDaHltQ9McGLdtCMGBuxBNWNc_RaI4m_FY");
        }


        titleInput = findViewById(R.id.titleInput);
        amountInput = findViewById(R.id.amountInput);
        dateInput = findViewById(R.id.dateInput);
        timeInput = findViewById(R.id.timeInput);
        locationInput = findViewById(R.id.locationInput);

        saveExpenseButton = findViewById(R.id.saveExpenseButton);
        selectDateButton = findViewById(R.id.selectDateButton);
        selectTimeButton = findViewById(R.id.selectTimeButton);
        selectLocationButton = findViewById(R.id.selectLocationButton);

        if (isDarkMode()) {
            getWindow().getDecorView().setBackgroundColor(getResources().getColor(R.color.background_dark));
        } else {
            getWindow().getDecorView().setBackgroundColor(getResources().getColor(R.color.background_light));
        }

        selectDateButton.setOnClickListener(v -> showDatePicker());
        selectTimeButton.setOnClickListener(v -> showTimePicker());
        selectLocationButton.setOnClickListener(v -> getLocation());
        saveExpenseButton.setOnClickListener(v -> saveExpense());
    }

    private boolean isDarkMode() {
        int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        return nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        new DatePickerDialog(this, (view, year, month, dayOfMonth) ->
                dateInput.setText(dayOfMonth + "/" + (month + 1) + "/" + year),
                calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void showTimePicker() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        String amPm = (hour >= 12) ? "PM" : "AM";
        int hour12 = (hour > 12) ? hour - 12 : (hour == 0) ? 12 : hour;

        new TimePickerDialog(this, (view, hourOfDay, minuteOfDay) -> {
            String formattedMinute = (minuteOfDay < 10) ? "0" + minuteOfDay : String.valueOf(minuteOfDay);
            timeInput.setText(hour12 + ":" + formattedMinute + " " + amPm);
        }, hour, minute, false).show();
    }

    private void getLocation() {
        List<Place.Field> fields = Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.ADDRESS);
        Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.FULLSCREEN, fields)
                .build(this);
        startActivityForResult(intent, AUTOCOMPLETE_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == AUTOCOMPLETE_REQUEST_CODE) {
            if (resultCode == RESULT_OK && data != null) {
                Place place = Autocomplete.getPlaceFromIntent(data);
                String location = place.getName() + ", " + place.getAddress();
                locationInput.setText(location);
            } else if (resultCode == AutocompleteActivity.RESULT_ERROR && data != null) {
                Status status = Autocomplete.getStatusFromIntent(data);
                Toast.makeText(this, "Location error: " + status.getStatusMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void saveExpense() {
        String title = titleInput.getText().toString().trim();
        String amountStr = amountInput.getText().toString().trim();
        String date = dateInput.getText().toString();
        String time = timeInput.getText().toString();
        String location = locationInput.getText().toString();

        if (title.isEmpty() || amountStr.isEmpty() || date.isEmpty() || time.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid amount", Toast.LENGTH_SHORT).show();
            return;
        }

        new Thread(() -> {
            Database dbHelper = new Database(ExpenseRecordingActivity.this);
            boolean success = dbHelper.addexpense(title, amount, date, time, location);

            runOnUiThread(() -> {
                if (success) {
                    Toast.makeText(this, "Expense saved", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(this, "Failed to save expense", Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }
}
