package com.example.expense_tracker2;

import android.content.Context;
import android.content.res.Configuration;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ExpenseAdapter extends RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder> {

    private final Context context;
    private final ArrayList<Expense> list;
    private final boolean isDarkMode;

    public ExpenseAdapter(Context context, ArrayList<Expense> list) {
        this.context = context;
        this.list = list;
        int currentNightMode = context.getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK;
        isDarkMode = (currentNightMode == Configuration.UI_MODE_NIGHT_YES);
    }

    @NonNull
    @Override
    public ExpenseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.expense_item, parent, false);
        return new ExpenseViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ExpenseViewHolder holder, int position) {
        Expense expense = list.get(position);
        holder.title.setText(expense.title);
        holder.amount.setText("\u00a3" + expense.amount);
        holder.datetime.setText(expense.date + " " + expense.time);
        holder.location.setText(expense.location);

        int bgColor = isDarkMode
                ? ContextCompat.getColor(context, R.color.background_dark)
                : ContextCompat.getColor(context, R.color.background_light);
        int textColor = isDarkMode
                ? ContextCompat.getColor(context, R.color.text_light)
                : ContextCompat.getColor(context, R.color.text_dark);

        holder.itemView.setBackgroundColor(bgColor);
        holder.title.setTextColor(textColor);
        holder.amount.setTextColor(textColor);
        holder.datetime.setTextColor(textColor);
        holder.location.setTextColor(textColor);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class ExpenseViewHolder extends RecyclerView.ViewHolder {
        TextView title, amount, datetime, location;

        ExpenseViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.expenseTitle);
            amount = itemView.findViewById(R.id.expenseAmount);
            datetime = itemView.findViewById(R.id.expenseDateTime);
            location = itemView.findViewById(R.id.expenseLocation);
        }
    }
}
