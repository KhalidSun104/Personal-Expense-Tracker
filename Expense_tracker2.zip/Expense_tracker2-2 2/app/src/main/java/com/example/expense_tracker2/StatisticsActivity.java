package com.example.expense_tracker2;

import android.content.res.Configuration;
import android.database.Cursor;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;

import java.util.ArrayList;

public class StatisticsActivity extends AppCompatActivity {

    PieChart pieChart;
    BarChart barChart;
    Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);

        pieChart = findViewById(R.id.pieChart);
        barChart = findViewById(R.id.barChart);
        db = new Database(this);

        int textColor;
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;

        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            textColor = getResources().getColor(R.color.text_light, getTheme());
        } else {
            textColor = getResources().getColor(R.color.text_dark, getTheme());
        }

        showPieChart(textColor);
        showBarChart(textColor);
    }

    private void showPieChart(int textColor) {
        ArrayList<PieEntry> entries = new ArrayList<>();
        Cursor cursor = db.readalldata();

        if (cursor.moveToFirst()) {
            do {
                String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
                float amount = cursor.getFloat(cursor.getColumnIndexOrThrow("amount"));
                entries.add(new PieEntry(amount, title));
            } while (cursor.moveToNext());
        }

        PieDataSet dataSet = new PieDataSet(entries, "Expenses");
        dataSet.setColors(new int[]{
                R.color.purple_200,
                R.color.teal_200,
                android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light,
                android.R.color.darker_gray,
                android.R.color.holo_purple,
                android.R.color.background_light,
                android.R.color.holo_blue_light,
                android.R.color.holo_green_dark,
        }, this);

        PieData data = new PieData(dataSet);
        pieChart.setData(data);

        pieChart.getLegend().setTextColor(textColor);
        pieChart.getDescription().setTextColor(textColor);
        pieChart.getData().setValueTextColor(textColor);

        pieChart.invalidate();
    }

    private void showBarChart(int textColor) {
        ArrayList<BarEntry> entries = new ArrayList<>();
        Cursor cursor = db.readalldata();
        int index = 0;

        if (cursor.moveToFirst()) {
            do {
                float amount = cursor.getFloat(cursor.getColumnIndexOrThrow("amount"));
                entries.add(new BarEntry(index, amount));
                index++;
            } while (cursor.moveToNext());
        }

        BarDataSet barDataSet = new BarDataSet(entries, "Expenses");
        BarData barData = new BarData(barDataSet);
        barChart.setData(barData);

        barChart.getXAxis().setTextColor(textColor);
        barChart.getAxisLeft().setTextColor(textColor);
        barChart.getAxisRight().setTextColor(textColor);
        barChart.getLegend().setTextColor(textColor);
        barChart.getDescription().setTextColor(textColor);
        barData.setValueTextColor(textColor);

        barChart.invalidate();
    }
}
