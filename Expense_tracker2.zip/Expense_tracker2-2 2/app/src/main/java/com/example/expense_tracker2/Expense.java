package com.example.expense_tracker2;

public class Expense {
    int id;
    String title;
    double amount;
    String date;
    String time;
    String location;

    public Expense(int id, String title, double amount, String date, String time, String location) {
        this.id = id;
        this.title = title;
        this.amount = amount;
        this.date = date;
        this.time = time;
        this.location = location;
    }
}
