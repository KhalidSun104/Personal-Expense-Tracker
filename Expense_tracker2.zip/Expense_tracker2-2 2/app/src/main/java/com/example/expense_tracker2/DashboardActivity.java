package com.example.expense_tracker2;

import android.database.Cursor;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DashboardActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ExpenseAdapter adapter;
    ArrayList<Expense> expenseList;
    Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        recyclerView = findViewById(R.id.expenseRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        db = new Database(this);
        expenseList = new ArrayList<>();

        loadData();

        adapter = new ExpenseAdapter(this, expenseList);
        recyclerView.setAdapter(adapter);
    }

    private void loadData() {
        Cursor cursor = db.readalldata();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String title = cursor.getString(1);
                double amount = cursor.getDouble(2);
                String date = cursor.getString(3);
                String time = cursor.getString(4);
                String location = cursor.getString(5);

                expenseList.add(new Expense(id, title, amount, date, time, location));
            } while (cursor.moveToNext());
        }
        cursor.close();
    }
}
