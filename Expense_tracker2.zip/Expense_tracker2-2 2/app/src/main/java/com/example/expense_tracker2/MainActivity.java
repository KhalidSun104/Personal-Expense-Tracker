package com.example.expense_tracker2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    FirebaseAuth auth;
    Button logoutButton, addExpenseButton;
    TextView userDetails;
    FirebaseUser user;
    Switch toggleThemeSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        auth = FirebaseAuth.getInstance();
        logoutButton = findViewById(R.id.Log_out);
        addExpenseButton = findViewById(R.id.Add_Expense);
        userDetails = findViewById(R.id.User_details);
        toggleThemeSwitch = findViewById(R.id.Toggle_Theme);
        user = auth.getCurrentUser();


        if (user == null) {
            Intent intent = new Intent(getApplicationContext(), Login.class);
            startActivity(intent);
            finish();
        } else {
            userDetails.setText(user.getEmail());
        }


        logoutButton.setOnClickListener(v -> {
            auth.signOut();
            Intent intent = new Intent(getApplicationContext(), Login.class);
            startActivity(intent);
            finish();
        });


        addExpenseButton.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), ExpenseRecordingActivity.class);
            startActivity(intent);
        });


        toggleThemeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> toggleTheme(isChecked));


        Button dashboardButton = findViewById(R.id.View_Dashboard);
        dashboardButton.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), DashboardActivity.class);
            startActivity(intent);
        });


        Button statisticsButton = findViewById(R.id.View_Statistics);
        statisticsButton.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), StatisticsActivity.class);
            startActivity(intent);
        });
    }

    private void toggleTheme(boolean isChecked) {
        if (isChecked) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }
}